#pragma once

#define HTTP_SERVER "31.58.58.47"
#define HTTP_PORT 80

#define TFTP_SERVER "31.58.58.47"
